'use strict';

(async function main() {
  if (!location.pathname.startsWith('/validator')) return;

  const launchFragment = location.hash.slice(1);
  const fragmentUrl = new URLSearchParams(launchFragment).get('xcard_url');
  let initialTarget = normalizeTarget(fragmentUrl);
  if (initialTarget) {
    // Fallback for a direct load if the webNavigation event hasn't completed.
    try { await chrome.runtime.sendMessage({ type: 'REGISTER', url: initialTarget }); } catch (_err) {}
    try { history.replaceState(history.state, '', location.pathname + location.search); } catch (_err) {}
  }

  let target = initialTarget;
  for (let i = 0; !target && i < 30; i++) {
    try {
      const response = await chrome.runtime.sendMessage({ type: 'GET_PENDING' });
      if (response?.item?.url) target = normalizeTarget(response.item.url);
    } catch (_err) {}
    if (!target) await delay(200);
  }
  if (!target) return;

  await waitUntilBody();
  const notice = createNotice(target);
  let busy = false;
  const COMPLETION_TIMEOUT_MS = 90000;

  async function process() {
    if (busy) return;
    busy = true;
    notice.status('URL入力欄を探しています…', 'waiting');
    let input = null;
    for (let i = 0; i < 32; i++) {
      input = findArticleInput();
      if (input) break;
      await delay(400);
    }

    if (!input) {
      notice.status('入力欄を検出できません。X側の画面変更・機能停止・ログイン状態をご確認ください。', 'error');
      await report('入力欄を検出できません');
      busy = false;
      return;
    }

    try {
      input.focus();
      setInputValue(input, target);
      await delay(350);
      const submit = findSubmitButton(input);
      // Mark first, because a click may cause the page to navigate immediately.
      await chrome.runtime.sendMessage({ type: 'MARK_HANDLED', url: target });
      if (!submit) {
        notice.status('記事URLを入力しました。実行ボタンが不明なため、自動クリックはしていません。', 'warning');
        await report('URL入力のみ完了（実行ボタン未検出）');
      } else {
        // Set close permission for THIS article/tab before clicking, but do
        // not close just because a button was clicked.
        const armed = await chrome.runtime.sendMessage({ type: 'ARM_AUTO_CLOSE', url: target });
        if (!armed?.ok) {
          notice.status('完了監視の準備に失敗しました。ボタンを実行しますがタブは閉じません。', 'warning');
          await report('完了監視を開始できません');
          submit.click();
          return;
        }

        notice.status('Preview card実行中。成功ログが出たら直ちにこのタブを閉じます。', 'waiting');
        const watcher = watchValidatorCompletion({
          timeoutMs: COMPLETION_TIMEOUT_MS,
          onSuccess: async () => {
            notice.status('成功ログを確認しました。タブを閉じます。', 'waiting');
            const result = await chrome.runtime.sendMessage({ type: 'COMPLETE_AND_CLOSE', url: target });
            if (!result?.ok) {
              notice.status('成功ログを確認しましたが、自動クローズに失敗しました。', 'warning');
              await report('成功ログ確認／タブのクローズ失敗');
            }
          },
          onError: async (errorText) => {
            await chrome.runtime.sendMessage({ type: 'CANCEL_AUTO_CLOSE', url: target });
            notice.status('Validatorエラーを検出したためタブを残します: ' + errorText, 'error');
            await report('Validatorエラー: ' + errorText);
          },
          onTimeout: async () => {
            await chrome.runtime.sendMessage({ type: 'CANCEL_AUTO_CLOSE', url: target });
            notice.status('成功ログを確認できません。確認のため、このタブは残します。', 'warning');
            await report('成功ログを確認できず／タブを保持');
          }
        });
        try {
          submit.click();
          watcher.checkNow();
        } catch (clickError) {
          watcher.cancel();
          await chrome.runtime.sendMessage({ type: 'CANCEL_AUTO_CLOSE', url: target });
          throw clickError;
        }
      }
    } catch (err) {
      notice.status('操作エラー: ' + String(err?.message || err).slice(0, 120), 'error');
      await report('操作エラー');
    } finally {
      busy = false;
    }
  }

  notice.onRetry(process);
  await process();

  async function report(status) {
    try { await chrome.runtime.sendMessage({ type: 'REPORT', url: target, status }); } catch (_err) {}
  }
})();

// The Validator no longer renders the old card preview. Its *Log* panel still
// reports fetch/parse completion. Match BOTH success messages to avoid treating
// a successful network fetch followed by a parsing error as a completed run.
// Read only DOM text; we cannot verify an X cache purge from this response.
function evaluateValidatorLog(logText) {
  const text = String(logText || '');
  const error = text.match(/(?:^|\n)\s*(?:ERROR|FATAL|FAIL)\s*:\s*([^\n]*)/im)
    || text.match(/\b(?:failed to fetch|unable to fetch|card load failed)\b/i);
  if (error) return { state: 'error', detail: (error[1] || error[0]).trim().slice(0, 140) };
  if (/\bPage fetched successfully\b/i.test(text) && /\bCard loaded successfully\b/i.test(text)) {
    return { state: 'success' };
  }
  return { state: 'pending' };
}

function currentLogText() {
  // Prefer the contents of a log-labelled element when X exposes one.
  const candidates = document.querySelectorAll('pre, [role="log"], [id], [class]');
  const matches = [];
  for (const node of candidates) {
    const id = node.id || '';
    const classText = typeof node.className === 'string' ? node.className : '';
    const logNamed = /(?:^|[\s_-])(?:log|logs|logoutput|log-output)(?:$|[\s_-])/i.test(id + ' ' + classText);
    if (logNamed || node.tagName === 'PRE' || node.getAttribute('role') === 'log') {
      // A parent log panel may also contain its child pre; duplicates harmless.
      matches.push(node.innerText || node.textContent || '');
    }
  }
  const focused = matches.filter(t => /Page fetched successfully|Card loaded successfully|(?:^|\n)\s*ERROR:/i.test(t));
  if (focused.length) return focused.join('\n');
  // Backstop for builds with plain div/span log lines and no identifiable class.
  return document.body?.innerText || '';
}

function watchValidatorCompletion({ timeoutMs, onSuccess, onError, onTimeout }) {
  let finished = false;
  let timeout;
  let interval;
  let observer;
  // If this page already displayed a previous run, don't close for an old log.
  const baseline = currentLogText();
  const baselineResult = evaluateValidatorLog(baseline);
  let sawChange = false;
  let checkScheduled = false;

  function cancel() {
    finished = true;
    observer?.disconnect();
    clearTimeout(timeout);
    clearInterval(interval);
  }
  function checkNow() {
    if (finished) return;
    const text = currentLogText();
    if (text !== baseline) sawChange = true;
    if (!sawChange) return;
    const result = evaluateValidatorLog(text);
    if (result.state === 'pending') return;
    // If X reuses existing success logs, require a change in the DOM after
    // the new click, not the old success state alone.
    if (result.state === 'success' && baselineResult.state === 'success') {
      const baselineWithoutWhitespace = baseline.replace(/\s+/g, ' ');
      if (text.replace(/\s+/g, ' ') === baselineWithoutWhitespace) return;
    }
    cancel();
    if (result.state === 'success') void onSuccess();
    else void onError(result.detail || '不明なエラー');
  }
  function scheduleCheck() {
    if (checkScheduled || finished) return;
    checkScheduled = true;
    queueMicrotask(() => { checkScheduled = false; checkNow(); });
  }
  observer = new MutationObserver(scheduleCheck);
  observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  interval = setInterval(checkNow, 250);
  timeout = setTimeout(() => { if (!finished) { cancel(); void onTimeout(); } }, timeoutMs);
  return { checkNow, cancel };
}

function normalizeTarget(candidate) {
  try {
    if (typeof candidate !== 'string' || candidate.length > 8192) return null;
    const u = new URL(candidate.trim());
    if (!['http:', 'https:'].includes(u.protocol) || !u.hostname || u.username || u.password) return null;
    return u.href;
  } catch (_err) { return null; }
}

function delay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

function waitUntilBody() {
  return new Promise(resolve => {
    if (document.body) return resolve();
    const observer = new MutationObserver(() => {
      if (document.body) { observer.disconnect(); resolve(); }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
  });
}

function visible(el) {
  if (el.disabled || el.closest('[hidden], [aria-hidden="true"]')) return false;
  const style = getComputedStyle(el);
  if (style.display === 'none' || style.visibility === 'hidden') return false;
  const rect = el.getBoundingClientRect();
  return rect.width > 1 && rect.height > 1;
}

function findArticleInput() {
  let best = null;
  let bestScore = 0;
  const candidates = document.querySelectorAll('input:not([type="hidden"]), textarea');
  for (const node of candidates) {
    if (!visible(node) || node.readOnly) continue;
    const kind = (node.getAttribute('type') || 'text').toLowerCase();
    if (!['url', 'search', 'text'].includes(kind) && node.tagName !== 'TEXTAREA') continue;
    const labels = Array.from(node.labels || []).map(l => l.textContent).join(' ');
    const attrs = [node.name, node.id, node.placeholder, node.getAttribute('aria-label'), labels].join(' ').toLowerCase();
    const parentText = (node.closest('form')?.textContent || node.parentElement?.textContent || '').slice(0, 400).toLowerCase();
    let score = kind === 'url' ? 6 : 0;
    if (/\burl\b|website|web ?address|link|https?:\/\/|ウェブ|サイトurl|リンク先/i.test(attrs)) score += 6;
    if (/card|validator|twitter|x\.com|preview|カード|検証/i.test(attrs)) score += 2;
    if (/card validator|preview card|url to validate|カード検証|card url/i.test(parentText)) score += 2;
    if (/search twitter|検索|サーチ|ユーザー名|username|password|メール|ログイン|sign in/i.test(attrs)) score -= 10;
    if (score > bestScore) { best = node; bestScore = score; }
  }
  return bestScore >= 4 ? best : null;
}

function setInputValue(input, value) {
  const proto = input.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
  if (setter) setter.call(input, value); else input.value = value;
  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
}

function findSubmitButton(input) {
  const root = input.closest('form') || document;
  const buttons = [...root.querySelectorAll('button, input[type="submit"], input[type="button"], [role="button"]')].filter(visible);
  const valid = /^(preview(?:\s+card)?|validate(?:\s+card)?|fetch|refetch|re-fetch|refresh|check(?:\s+card)?|submit(?:\s+url)?|go|プレビュー|検証|再取得|確認|表示)(?:\s*[→›>])?$/i;
  let best = null;
  let bestScore = 0;
  for (const button of buttons) {
    const label = [button.innerText, button.value, button.getAttribute('aria-label'), button.title].filter(Boolean).join(' ').trim();
    if (/login|sign ?in|log ?in|password|ログイン|同意|accept/i.test(label)) continue;
    const normalized = label.replace(/\s+/g, ' ').toLowerCase();
    let score = valid.test(normalized) ? 8 : 0;
    if (/preview card|validate|refresh|再取得|検証|プレビュー/i.test(normalized)) score += 5;
    if (button.type === 'submit' && root !== document) score += 2;
    if (score > bestScore) { best = button; bestScore = score; }
  }
  // Do not click unidentified buttons. They may be unrelated X controls.
  return bestScore >= 7 ? best : null;
}

function createNotice(url) {
  const host = document.createElement('div');
  host.id = 'xcard-helper-status';
  host.style.cssText = 'position:fixed;z-index:2147483647;right:16px;bottom:16px;width:min(380px,calc(100vw - 32px));';
  const shadow = host.attachShadow({ mode: 'closed' });
  const css = document.createElement('style');
  css.textContent = `
    * {box-sizing:border-box;font-family:system-ui,-apple-system,"Yu Gothic UI",Meiryo,sans-serif}
    .panel {background:#111827;color:#f9fafb;border:1px solid #475569;border-radius:14px;padding:16px;box-shadow:0 12px 34px rgba(0,0,0,.35);font-size:13px;line-height:1.5}
    header {display:flex;gap:8px;align-items:center;justify-content:space-between}
    h2 {font-size:15px;margin:0;font-weight:700}
    .close {padding:0 3px;border:0;background:none;color:#94a3b8;font-size:22px;cursor:pointer}
    .url {font-size:11px;color:#a5b4fc;word-break:break-all;margin:12px 0}
    .state {background:#1e293b;border-radius:8px;padding:9px 10px;line-height:1.6}
    .state[data-state=error] {color:#fecaca}
    .state[data-state=warning] {color:#fde68a}
    .actions {display:flex;gap:8px;margin-top:12px}
    button.action {background:#334155;color:white;border:1px solid #64748b;padding:8px 12px;border-radius:8px;cursor:pointer;font-size:12px}
    button.primary {background:#2563eb;border-color:#2563eb}
    footer {color:#94a3b8;font-size:10px;margin-top:10px}
  `;
  const panel = document.createElement('div');
  panel.className = 'panel';
  const header = document.createElement('header');
  const heading = document.createElement('h2');
  heading.textContent = 'X Card Helper';
  const close = document.createElement('button');
  close.className = 'close'; close.textContent = '×'; close.title = '閉じる';
  close.addEventListener('click', () => host.remove());
  header.append(heading, close);
  const urlText = document.createElement('div'); urlText.className = 'url'; urlText.textContent = url;
  const status = document.createElement('div'); status.className = 'state'; status.textContent = '準備中…'; status.setAttribute('aria-live', 'polite');
  const actions = document.createElement('div'); actions.className = 'actions';
  const retry = document.createElement('button'); retry.className = 'action primary'; retry.textContent = '再試行';
  const copy = document.createElement('button'); copy.className = 'action'; copy.textContent = '記事URLをコピー';
  copy.addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(url); copy.textContent = 'コピーしました'; }
    catch (_err) { copy.textContent = 'コピーできませんでした'; }
  });
  actions.append(retry, copy);
  const footer = document.createElement('footer');
  footer.textContent = '操作実行 ≠ X側のキャッシュ更新成功。状況は必ず確認してください。';
  panel.append(header, urlText, status, actions, footer);
  shadow.append(css, panel);
  document.body.appendChild(host);
  return {
    status(message, state) { status.textContent = message; status.dataset.state = state; },
    onRetry(callback) { retry.addEventListener('click', callback); }
  };
}
