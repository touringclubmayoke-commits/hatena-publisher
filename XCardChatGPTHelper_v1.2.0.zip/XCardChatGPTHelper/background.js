'use strict';

// This extension intentionally handles ONLY explicit #xcard_url= launches
// on cards-dev.x.com/validator. It does not inspect ChatGPT conversations.
const VALIDATOR_ORIGIN = 'https://cards-dev.x.com';
const VALIDATOR_PATH = '/validator';
const HASH_KEY = 'xcard_url';
const MAX_PENDING_AGE_MS = 30 * 60 * 1000;
const PENDING_PREFIX = 'pending_tab_';
// Close ONLY the tab that launched this article AND only after the content
// script sees completion messages from the Validator log. A click alone never
// schedules a close, and moving to another page cancels any closing ability.
async function closeValidatedTab(tabId, target) {
  if (!Number.isInteger(tabId) || tabId < 0) return false;
  const key = pendingKey(tabId);
  const item = (await chrome.storage.session.get(key))[key];
  if (!item?.handled || !item.autoCloseArmed || item.url !== target) return false;
  try {
    const tab = await chrome.tabs.get(tabId);
    if (!tab?.url || !fromValidatorPage(tab.url)) return false;
    await chrome.storage.local.set({
      lastResult: { url: target, status: 'Validator成功ログを確認してタブを閉じました（X側のキャッシュ更新は未保証）', at: Date.now() }
    });
    await chrome.tabs.remove(tabId);
    return true;
  } catch (_err) {
    return false;
  }
}

function fromValidatorPage(candidate) {
  try {
    const u = new URL(candidate);
    return u.origin === VALIDATOR_ORIGIN &&
      (u.pathname === VALIDATOR_PATH || u.pathname.startsWith(VALIDATOR_PATH + '/'));
  } catch (_err) {
    return false;
  }
}


function normalizeTarget(candidate) {
  try {
    if (typeof candidate !== 'string' || candidate.length > 8192) return null;
    const u = new URL(candidate.trim());
    if (!['http:', 'https:'].includes(u.protocol) || !u.hostname || u.username || u.password) return null;
    return u.href;
  } catch (_err) {
    return null;
  }
}

function fromLaunchUrl(candidate) {
  try {
    const u = new URL(candidate);
    if (u.origin !== VALIDATOR_ORIGIN || !u.pathname.startsWith(VALIDATOR_PATH)) return null;
    const fragment = u.hash.startsWith('#') ? u.hash.slice(1) : '';
    return normalizeTarget(new URLSearchParams(fragment).get(HASH_KEY));
  } catch (_err) {
    return null;
  }
}

function pendingKey(tabId) {
  return PENDING_PREFIX + String(tabId);
}

async function registerPending(tabId, url) {
  const target = normalizeTarget(url);
  if (!target || !Number.isInteger(tabId) || tabId < 0) return false;
  const key = pendingKey(tabId);
  await chrome.storage.session.set({ [key]: { url: target, at: Date.now(), handled: false } });
  await chrome.storage.local.set({ lastUrl: target });
  return true;
}

// Captures the URL fragment *before* an HTTP redirect to X login can drop it.
// Chrome fires this event for navigations to the validator; non-Validator URLs
// are filtered out by the browser before they reach this listener.
function captureNavigation(details) {
  if (details.frameId !== 0 || details.tabId < 0) return;
  const url = fromLaunchUrl(details.url);
  if (!url) return;
  registerPending(details.tabId, url).catch(console.warn);
}

const validatorFilter = { url: [{ schemes: ['https'], hostEquals: 'cards-dev.x.com', pathPrefix: '/validator' }] };
chrome.webNavigation.onBeforeNavigate.addListener(captureNavigation, validatorFilter);
chrome.webNavigation.onReferenceFragmentUpdated.addListener(captureNavigation, validatorFilter);

chrome.tabs.onRemoved.addListener((tabId) => {
  chrome.storage.session.remove(pendingKey(tabId)).catch(() => {});
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    switch (message?.type) {
      case 'REGISTER': {
        if (!sender.tab || !sender.url?.startsWith(VALIDATOR_ORIGIN + VALIDATOR_PATH)) return { ok: false };
        return { ok: await registerPending(sender.tab.id, message.url) };
      }
      case 'GET_PENDING': {
        if (!sender.tab || !sender.url?.startsWith(VALIDATOR_ORIGIN + VALIDATOR_PATH)) return { ok: false };
        const key = pendingKey(sender.tab.id);
        const item = (await chrome.storage.session.get(key))[key];
        if (!item || item.handled) return { ok: true, item: null };
        if (Date.now() - item.at > MAX_PENDING_AGE_MS) {
          await chrome.storage.session.remove(key);
          return { ok: true, item: null };
        }
        return { ok: true, item };
      }
      case 'MARK_HANDLED': {
        if (!sender.tab || !sender.url?.startsWith(VALIDATOR_ORIGIN + VALIDATOR_PATH)) return { ok: false };
        const key = pendingKey(sender.tab.id);
        const item = (await chrome.storage.session.get(key))[key];
        if (!item || item.url !== message.url) return { ok: false };
        await chrome.storage.session.set({ [key]: { ...item, handled: true } });
        return { ok: true };
      }
      case 'REPORT': {
        if (!sender.tab || !sender.url?.startsWith(VALIDATOR_ORIGIN + VALIDATOR_PATH)) return { ok: false };
        const status = String(message.status || '').slice(0, 220);
        const target = normalizeTarget(message.url);
        if (!target) return { ok: false };
        await chrome.storage.local.set({ lastResult: { url: target, status, at: Date.now() } });
        return { ok: true };
      }
      case 'ARM_AUTO_CLOSE': {
        if (!sender.tab || !fromValidatorPage(sender.url)) return { ok: false };
        const key = pendingKey(sender.tab.id);
        const item = (await chrome.storage.session.get(key))[key];
        if (!item?.handled || item.url !== message.url) return { ok: false };
        await chrome.storage.session.set({ [key]: { ...item, autoCloseArmed: true } });
        return { ok: true };
      }
      case 'CANCEL_AUTO_CLOSE': {
        if (!sender.tab || !fromValidatorPage(sender.url)) return { ok: false };
        const key = pendingKey(sender.tab.id);
        const item = (await chrome.storage.session.get(key))[key];
        if (!item || item.url !== message.url) return { ok: false };
        await chrome.storage.session.set({ [key]: { ...item, autoCloseArmed: false } });
        return { ok: true };
      }
      case 'COMPLETE_AND_CLOSE': {
        if (!sender.tab || !fromValidatorPage(sender.url)) return { ok: false };
        return { ok: await closeValidatedTab(sender.tab.id, message.url) };
      }
      default:
        return { ok: false, error: 'Unknown command' };
    }
  })().then(sendResponse).catch((e) => sendResponse({ ok: false, error: String(e) }));
  return true;
});
