'use strict';

const textarea = document.getElementById('articleUrl');
const error = document.getElementById('error');
const button = document.getElementById('launch');
const copy = document.getElementById('copy');
const lastResult = document.getElementById('lastResult');

function normalizeTarget(candidate) {
  try {
    if (!candidate || candidate.length > 8192) return null;
    const u = new URL(candidate.trim());
    if (!['http:', 'https:'].includes(u.protocol) || !u.hostname || u.username || u.password) return null;
    return u.href;
  } catch (_err) { return null; }
}

function launchLink(url) {
  // Hash is not sent in the HTTP request, but the extension can receive it
  // via chrome.webNavigation before a potential login redirect.
  return 'https://cards-dev.x.com/validator#xcard_url=' + encodeURIComponent(url);
}

function enteredUrl() {
  const url = normalizeTarget(textarea.value);
  if (!url) {
    error.textContent = 'http:// または https:// で始まる正しい記事URLを入力してください。';
    return null;
  }
  error.textContent = '';
  return url;
}

button.addEventListener('click', async () => {
  const url = enteredUrl();
  if (!url) return;
  await chrome.storage.local.set({ lastUrl: url });
  await chrome.tabs.create({ url: launchLink(url) });
  window.close();
});

copy.addEventListener('click', async () => {
  const url = enteredUrl();
  if (!url) return;
  try {
    await navigator.clipboard.writeText(launchLink(url));
    copy.textContent = 'コピーしました';
  } catch (_err) {
    error.textContent = 'リンクをコピーできませんでした。';
  }
});

(async () => {
  const data = await chrome.storage.local.get(['lastUrl', 'lastResult']);
  if (data.lastUrl) textarea.value = data.lastUrl;
  const result = data.lastResult;
  if (result) lastResult.textContent = `${new Date(result.at).toLocaleString('ja-JP')} — ${result.status}`;
})();
